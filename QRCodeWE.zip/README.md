# QRCodeWE
QRCode Web Extension

>Simple Web Extension to generate a QRCode with the current URL.

## Credits

[davidshimjs/qrcodejs](https://github.com/davidshimjs/qrcodejs)

## Links

[Chrome Web Store](https://chrome.google.com/webstore/detail/qrcode-web-extension/olbmcjijmiibmlflipolnfjnmeapknpj)

[Firefox Browser ADD-ONS](https://addons.mozilla.org/pt-BR/firefox/addon/qrcode-web-extension/)
